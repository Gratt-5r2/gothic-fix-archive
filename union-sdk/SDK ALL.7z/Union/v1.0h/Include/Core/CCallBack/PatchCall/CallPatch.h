// Supported with union (c) 2018 Union team

#ifndef __UNION_CALLPATCH_H__
#define __UNION_CALLPATCH_H__

#define PATCH( from, to ) = AutoModulePatchCallInvoker_BySignature( #from, to )

namespace UnionCore {

  struct ModuleRange {
    HMODULE module;
    uint base;
    uint length;
  };



  struct ModuleCallCollision {
    ModuleRange moduleRange;
    byte instruction;
    byte* memory;
    uint address;
  };



  class ASTAPI ModulePatchCallInfo {
    static Array<ModulePatchCallInfo*> patches;
    Array<ModuleCallCollision> collisions;
    ModulePatchCallInfo* prev;
    ModulePatchCallInfo* next;
    uint origin;
    uint address;
    uint References;

    void DisableCallPatch();
    void EnableCallPatch();
  public:

    ModulePatchCallInfo();
    void SetCallPatch( uint from, uint to );
    void RemoveCallPatch();
    void AddRef();
    void Release();

    ModulePatchCallInfo* GetFirst();
    ModulePatchCallInfo* GetLast();
    uint GetOrigin();
    uint GetAddress();
    uint GetReturnAddress();
    ~ModulePatchCallInfo();

    static ModulePatchCallInfo* FindPatchedCallInfo( uint address );
  };



  ModuleRange ASTAPI GetModuleRange( HMODULE module );
  bool ASTAPI CheckModuleCallCollision( ModuleRange& moduleRange, byte* memory, uint address, ModuleCallCollision& collision );
  Array<ModuleCallCollision> ASTAPI GetModuleCallCollisions( HMODULE module, uint address );
  void ASTAPI SetModuleCallPatch( const ModuleCallCollision& collision, uint newAddress );
  void ASTAPI SetModuleCallPatch( const Array<ModuleCallCollision>& collisions, uint newAddress );
  void ASTAPI RestorePatchedModuleCall( const ModuleCallCollision& collision );
  void ASTAPI RestorePatchedModuleCall( const Array<ModuleCallCollision>& collisions );

  template<class T>
  T SelectModuleCallPatchFunction( T same, uint address ) {
    ModulePatchCallInfo* patch = ModulePatchCallInfo::FindPatchedCallInfo( address );
    if( patch ) {
      uint64 returnAddress = patch->GetLast()->GetAddress();
      return *(T*)&returnAddress;
    }

    return same;
  }




  template<class T>
  class ModulePatchCallInvoker {
    ModulePatchCallInfo* patch;
  public:

    ModulePatchCallInvoker( const ModulePatchCallInvoker<T>& other );
    ModulePatchCallInvoker( TInstance from, TInstance to );
    void Attach( TInstance from, TInstance to );
    void Detach();
    operator T();
    T CastToPointer() const;
    ~ModulePatchCallInvoker();
  };



  template<class T>
  ModulePatchCallInvoker<T>::ModulePatchCallInvoker( const ModulePatchCallInvoker<T>& other ) {
    patch = other->patch;
    patch->AddRef();
  }



  template<class T>
  ModulePatchCallInvoker<T>::ModulePatchCallInvoker( TInstance from, TInstance to ) {
    Attach( from, to );
  }



  template<class T>
  void ModulePatchCallInvoker<T>::Attach( TInstance from, TInstance to ) {
    if( from.data == Null || to.data == Null )
      return;

    if( patch )
      Detach();

    patch = new ModulePatchCallInfo();
    patch->SetCallPatch( (uint)from.data, (uint)to.data );
  }



  template<class T>
  void ModulePatchCallInvoker<T>::Detach() {
    patch->RemoveCallPatch();
    patch->Release();
    patch = Null;
  }



  template<class T>
  ModulePatchCallInvoker<T>::operator T() {
    return CastToPointer();
  }



  template<class T>
  T ModulePatchCallInvoker<T>::CastToPointer() const {
    uint64 returnAddress = patch ? patch->GetReturnAddress() : 0;
    return *(T*)&returnAddress;
  }



  //
  template<class T>
  ModulePatchCallInvoker<T>::~ModulePatchCallInvoker() {
    if( patch )
      patch->Release();
  }



  template <typename T, typename O>
  inline ModulePatchCallInvoker<T> AutoModulePatchCallInvoker( O oldfunc, T newfunc ) {
    void* oldfunc_pointer = (void*&)oldfunc;
    void* newfunc_pointer = (void*&)newfunc;
    return ModulePatchCallInvoker<T>( oldfunc_pointer, newfunc_pointer );
  }
}

#endif // __UNION_CALLPATCH_H__