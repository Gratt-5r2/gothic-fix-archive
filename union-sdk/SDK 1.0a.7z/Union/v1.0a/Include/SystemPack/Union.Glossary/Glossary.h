#pragma once

namespace SystemPack
{
	class CGlossaryWord
	{
		struct TWordInfo
		{
			uint32	ulLangIndex;
			CString	sData;
		};
		CString sKeyName;
		CArray<TWordInfo*> arrInfos;
	public:
		CGlossaryWord(const CString& keyName);

		CString		GetKeyName	();
		TWordInfo*	GetData		(const uint32& langID);
		void		SetData		(const uint32& langID, const CString& data);
		void		Merge		(CGlossaryWord* word);
	};
};

#include "HashTable\HashTable.h"

namespace SystemPack
{
	class CGlossary
	{
		CHashTable tblData;
	public:
		static void LoadGlossaries(const CString& list);

		void			LoadFile(const CString& fileName);
		CGlossaryWord*	GetWord	(const CString& keyName);
	};
}