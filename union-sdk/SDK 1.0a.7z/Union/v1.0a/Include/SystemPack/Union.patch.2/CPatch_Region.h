#pragma once

namespace SystemPack
{
	
	class CPatch_Region
	{
		CString sCurrentPatch;

	protected:
		uint32	  ulOffset;
		CDocument sRegionData;

	public:

		static CPatch_Region* DefineBlock (CDocument& fileData, const uint32& hash);
		void   ExecuteRegion ();
		uint32 ExecuteOnLine (uint32 line);

		~CPatch_Region();
	};


}