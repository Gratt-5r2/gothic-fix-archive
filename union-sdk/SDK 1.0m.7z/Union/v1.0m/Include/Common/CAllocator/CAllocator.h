// Supported with union (c) 2018-2021 Union team

#ifndef __UNION_ALLOCATOR_H__
#define __UNION_ALLOCATOR_H__

#include "allocator32.h"
#include "allocator64.h"

#endif // __UNION_ALLOCATOR_H__