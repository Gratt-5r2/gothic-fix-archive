// Supported with union (c) 2018 Union team

#ifndef __PATCH_FILE_H__
#define __PATCH_FILE_H__

#include "Filters\Filters.h"
#include "MemPage\CMemPage.h"
#include "Symbol\CPatchSymbol.h"
#include "Stack\CPatchStack.h"
#include "Region\CPatchRegion.h"

namespace SystemPack {
  class ASTAPI CPatchFile {
    CString	  sFileName;
    CDocument sFileData;
  protected:
    CPatchFile( const CString& fileName );
  public:
    CPatchRegion* CreateEngineBlock( const uint32& hash );
    void CloseFile();
    static CPatchFile* LoadFile( const CString& fileName );
  };

  class ASTAPI CPatch {
    CString sName;

    static CArray<CPatch*> arrPatches;
  public:
    CPatch( const CString& name );
    void Execute();
    static void ExecuteAll();
    static bool32 HasPatch( const char* name );
  };
}

#endif // __PATCH_FILE_H__