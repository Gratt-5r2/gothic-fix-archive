
#define CStringA  Common::CStringA
#define CStringW  Common::CStringW
#define CString   CStringA
#define CDocument Common::CDocument
#define COption   Common::COption
#define CList     Common::CList