
extern const wtext err_unknown_engine				[Lang_Max];
extern const wtext err_already_attached				[Lang_Max];
extern const wtext err_hook_attach_protected		[Lang_Max];
extern const wtext err_hook_redefine_protected		[Lang_Max];
extern const wtext err_hook_detach_protected		[Lang_Max];
extern const wtext err_plugin_already_loaded		[Lang_Max];
extern const wtext err_plugin_not_loaded			[Lang_Max];
extern const wtext err_splash_resource_not_loaded	[Lang_Max];
extern const wtext err_splash_bitmap_not_loaded		[Lang_Max];