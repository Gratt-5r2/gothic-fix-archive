
#undef CStringA
#undef CStringW
#undef CString
#undef string
#undef CDocument
#undef COption
#undef CList